package com.example.streammodern

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF101116)
private val Surface = Color(0xFF1B1D25)
private val Accent = Color(0xFFB9F36A)
private val Muted = Color(0xFF9A9DAB)

private data class Show(val title: String, val year: String, val genre: String, val rating: String, val description: String, val emoji: String, val colors: List<Color>)
private val shows = listOf(
    Show("Midnight Protocol", "2026", "Thriller", "8.7", "A cryptic message pulls a quiet analyst into a conspiracy that reaches the highest levels of power.", "🌃", listOf(Color(0xFF263B65), Color(0xFF8B4C76))),
    Show("Beyond the Horizon", "2025", "Adventure", "8.4", "A crew of explorers searches for a new home beyond the edge of the known world.", "🌌", listOf(Color(0xFF155E75), Color(0xFF4C498A))),
    Show("The Last Summer", "2026", "Drama", "8.1", "One unforgettable summer changes the lives of four friends forever.", "🌅", listOf(Color(0xFFB4533C), Color(0xFF5D426F))),
    Show("Neon District", "2024", "Sci-Fi", "9.0", "In a city that never sleeps, a street engineer discovers a secret hidden inside the network.", "🌆", listOf(Color(0xFF4C1D95), Color(0xFF0E7490))),
    Show("Wild Hearts", "2025", "Romance", "7.9", "Two strangers find an unexpected connection while rebuilding a remote coastal town.", "🌊", listOf(Color(0xFF0F766E), Color(0xFF60A5FA))),
    Show("Paper Kingdom", "2026", "Mystery", "8.6", "A forgotten journal opens a case that was supposed to stay buried.", "📜", listOf(Color(0xFF854D0E), Color(0xFF713F12)))
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StreamModernApp() }
    }
}

@Composable
private fun StreamModernApp() {
    var selected by remember { mutableStateOf<Show?>(null) }
    var query by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("All") }
    var tab by remember { mutableStateOf("Home") }
    val categories = listOf("All", "Action", "Drama", "Thriller", "Sci-Fi", "Romance", "Adventure", "Mystery")
    val filtered = shows.filter { (query.isBlank() || it.title.contains(query, true) || it.genre.contains(query, true)) && (category == "All" || it.genre == category) }

    MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Surface, primary = Accent, onBackground = Color.White, onSurface = Color.White)) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            if (selected != null) {
                DetailScreen(show = selected!!, onBack = { selected = null })
            } else {
                Column(Modifier.fillMaxSize()) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("STREAM", fontSize = 12.sp, letterSpacing = 4.sp, color = Accent, fontWeight = FontWeight.Bold)
                            Text("Your next obsession.", fontSize = 23.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                        }
                        Box(Modifier.size(44.dp).clip(CircleShape).background(Surface), contentAlignment = Alignment.Center) {
                            Text("S", color = Accent, fontWeight = FontWeight.Black, fontSize = 21.sp)
                        }
                    }
                    OutlinedTextField(
                        value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp),
                        placeholder = { Text("Search movies and series…", color = Muted) }, leadingIcon = { Icon(Icons.Default.Search, null, tint = Muted) },
                        singleLine = true, shape = RoundedCornerShape(16.dp), colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Accent, unfocusedBorderColor = Color(0xFF343641), focusedContainerColor = Surface, unfocusedContainerColor = Surface,
                            focusedTextColor = Color.White, unfocusedTextColor = Color.White
                        )
                    )
                    Spacer(Modifier.height(18.dp))
                    if (query.isBlank() && category == "All") {
                        val hero = shows.first()
                        Box(Modifier.fillMaxWidth().padding(horizontal = 18.dp).height(190.dp).clip(RoundedCornerShape(24.dp)).background(Brush.linearGradient(hero.colors)).clickable { selected = hero }) {
                            Column(Modifier.align(Alignment.CenterStart).padding(20.dp).fillMaxWidth(0.75f)) {
                                Text("EDITOR'S PICK", color = Accent, fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(7.dp))
                                Text(hero.title, color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 29.sp)
                                Text("${hero.year}  •  ${hero.genre}  •  ★ ${hero.rating}", color = Color.White.copy(alpha = .82f), fontSize = 12.sp)
                                Spacer(Modifier.height(12.dp))
                                Row(Modifier.clip(RoundedCornerShape(50)).background(Accent).padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.PlayArrow, null, tint = Bg, modifier = Modifier.size(18.dp)); Text("  Explore", color = Bg, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }
                            Text(hero.emoji, Modifier.align(Alignment.CenterEnd).padding(end = 16.dp), fontSize = 58.sp)
                        }
                    }
                    Spacer(Modifier.height(18.dp))
                    Text("Browse by mood", Modifier.padding(horizontal = 20.dp), color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        categories.forEach { item ->
                            FilterChip(selected = category == item, onClick = { category = item }, label = { Text(item) }, colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Accent, selectedLabelColor = Bg, labelColor = Muted), border = FilterChipDefaults.filterChipBorder(enabled = true, selected = category == item, borderColor = Color(0xFF353741), selectedBorderColor = Accent))
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(if (query.isBlank()) "Trending now" else "Search results", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        Text("${filtered.size} titles", color = Muted, fontSize = 12.sp)
                    }
                    Spacer(Modifier.height(8.dp))
                    LazyColumn(contentPadding = PaddingValues(start = 18.dp, end = 18.dp, bottom = 20.dp), verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.weight(1f)) {
                        items(filtered) { show -> ShowRow(show = show, onClick = { selected = show }) }
                        if (filtered.isEmpty()) item { Text("No titles found. Try another search.", color = Muted, modifier = Modifier.padding(18.dp)) }
                    }
                    NavigationBar(containerColor = Color(0xFF171920), contentColor = Muted) {
                        NavigationBarItem(selected = tab == "Home", onClick = { tab = "Home"; category = "All"; query = "" }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Home") }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Accent, selectedTextColor = Accent, indicatorColor = Color(0xFF2A3320)))
                        NavigationBarItem(selected = tab == "Search", onClick = { tab = "Search" }, icon = { Icon(Icons.Default.Search, null) }, label = { Text("Search") }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Accent, selectedTextColor = Accent, indicatorColor = Color(0xFF2A3320)))
                        NavigationBarItem(selected = tab == "Watchlist", onClick = { tab = "Watchlist" }, icon = { Icon(Icons.Default.BookmarkBorder, null) }, label = { Text("Watchlist") }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Accent, selectedTextColor = Accent, indicatorColor = Color(0xFF2A3320)))
                        NavigationBarItem(selected = tab == "Settings", onClick = { tab = "Settings" }, icon = { Icon(Icons.Default.Settings, null) }, label = { Text("Settings") }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Accent, selectedTextColor = Accent, indicatorColor = Color(0xFF2A3320)))
                    }
                }
            }
        }
    }
}

@Composable
private fun ShowRow(show: Show, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Surface).clickable(onClick = onClick).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(88.dp).height(100.dp).clip(RoundedCornerShape(13.dp)).background(Brush.linearGradient(show.colors)), contentAlignment = Alignment.Center) { Text(show.emoji, fontSize = 35.sp) }
        Spacer(Modifier.width(13.dp))
        Column(Modifier.weight(1f)) {
            Text(show.title, fontSize = 16.sp, color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(4.dp))
            Text("${show.year}  •  ${show.genre}", fontSize = 12.sp, color = Muted)
            Spacer(Modifier.height(7.dp))
            Text(show.description, fontSize = 12.sp, color = Color(0xFFCED0D8), maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 16.sp)
            Spacer(Modifier.height(6.dp))
            Text("★ ${show.rating}  ·  DETAILS  →", fontSize = 10.sp, color = Accent, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        }
    }
}

@Composable
private fun DetailScreen(show: Show, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxWidth().height(290.dp).background(Brush.linearGradient(show.colors))) {
            Text(show.emoji, Modifier.align(Alignment.Center), fontSize = 100.sp)
            IconButton(onClick = onBack, modifier = Modifier.align(Alignment.TopStart).padding(10.dp).clip(CircleShape).background(Color.Black.copy(alpha = .35f))) { Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White) }
            Text("STREAM MODERN", Modifier.align(Alignment.BottomStart).padding(20.dp), color = Accent, fontWeight = FontWeight.Bold, letterSpacing = 3.sp, fontSize = 11.sp)
        }
        Column(Modifier.fillMaxWidth().padding(22.dp)) {
            Text(show.title, fontSize = 29.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
            Spacer(Modifier.height(8.dp))
            Text("${show.year}  •  ${show.genre}  •  ★ ${show.rating}", color = Accent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(18.dp))
            Text("Synopsis", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text(show.description, color = Muted, fontSize = 15.sp, lineHeight = 23.sp)
            Spacer(Modifier.height(22.dp))
            Button(onClick = {}, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(15.dp), colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Bg)) {
                Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(8.dp)); Text("Playback integration pending", fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(10.dp))
            Text("Demo catalogue · Connect an authorized content API to load real titles and playback links.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
        }
    }
}
