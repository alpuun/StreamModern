# Build Stream Modern APK online (no Android Studio)

This project includes a GitHub Actions workflow that builds a debug APK in the cloud.

## Steps
1. On your phone browser, sign in to GitHub and create a **new private repository** (for example `StreamModern`).
2. Upload the **contents** of this project to the repository root. Ensure `.github/workflows/build-apk.yml` is included. If the GitHub mobile upload page hides dot-folders, use GitHub's web editor to create `.github/workflows/build-apk.yml` and paste the workflow from this project.
3. Open the repository's **Actions** tab and choose **Build Android APK**. If prompted, enable Actions, then tap **Run workflow**.
4. Wait for the workflow to finish successfully.
5. Open the completed run, scroll to **Artifacts**, and download `StreamModern-debug-apk`.
6. Extract the downloaded artifact ZIP. It contains `app-debug.apk`. Open it on Android to install. Android may ask you to allow installs from that browser/file manager.

Notes:
- This creates a **debug APK** for testing, not a Play Store release.
- This is only the app prototype. Live Loklok API and streaming playback have not been integrated.
- Never commit API keys, passwords, signing keys, or private credentials to a public repository. Use a private repository.
