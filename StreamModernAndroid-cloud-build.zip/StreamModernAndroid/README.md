# Stream Modern — Android starter project

Modern dark-themed Android UI prototype built with Kotlin and Jetpack Compose.

## Included
- Home page with featured title
- Search field and genre chips
- Demo title catalogue
- Detail screen
- Bottom navigation UI

## Current limitations
This is a UI prototype using sample data, not a finished streaming app. The supplied ZIP contains reverse-engineered Loklok API details. This project does not implement its private signing scheme, bypass authentication/access controls, fetch unauthorized streams, or download copyrighted videos. To make it functional, connect an API you own or are authorized to use and content/playback URLs you have rights to distribute. Playback is intentionally a placeholder.

## Open in Android Studio
1. Install Android Studio with Android SDK 35 or a compatible SDK.
2. Extract this project ZIP.
3. In Android Studio choose **Open** and select the `StreamModernAndroid` folder.
4. Allow Gradle sync to complete.
5. Run the `app` configuration on an Android emulator or a USB-connected device.
6. To create an APK, select **Build > Build APK(s)**. Android Studio will show the output path when finished.

Package: `com.example.streammodern`  
Minimum Android: 7.0 (API 24)  
Target SDK: 35
